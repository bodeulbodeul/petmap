package project.petmap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetmapApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetmapApplication.class, args);
	}

}

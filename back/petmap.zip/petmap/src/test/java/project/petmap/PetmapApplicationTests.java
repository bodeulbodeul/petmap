package project.petmap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetmapApplicationTests {

	@Test
	void contextLoads() {
	}

}
